Four Dollar Plastic Laminator

A Linux 1k intro by Saint Vincent and the Grenadines.
For TuM 2009.

Those are x64 binaries and they may or may not run on your box. Eh.

code: halcy, WAHa_06x36

Greets to K2, Saga_Musix, urs & las, nrr & nurupo staff, never,
britelite, soundemon and wlf.

Thanks to parcelshit^fearmoths for the 1k framework.
