//--------------------------------------------------------------------------//
// iq / rgba  .  tiny codes  .  2008                                        //
//--------------------------------------------------------------------------//

#ifndef _MAIN_H_
#define _MAIN_H_

#define ISFULLSCREEN
#define XRES    800
#define YRES    600

#endif